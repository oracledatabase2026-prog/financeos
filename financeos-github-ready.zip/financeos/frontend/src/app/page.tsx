'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, BarChart3, Shield, Zap, Globe, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/store/auth-store';

const features = [
  { icon: BarChart3, title: 'Advanced Analytics', desc: 'Real-time financial dashboards and KPIs' },
  { icon: Shield, title: 'Enterprise Security', desc: 'JWT auth with role-based permissions' },
  { icon: Zap, title: 'Lightning Fast', desc: 'Optimized for high-volume transactions' },
  { icon: Globe, title: 'Multi-Currency', desc: 'USD, EGP, EUR, GBP, SAR, AED support' },
];

const modules = [
  'General Ledger', 'Accounts Payable', 'Accounts Receivable',
  'Inventory Management', 'Financial Reports', 'HR & Payroll',
  'Journal Entries', 'Trial Balance', 'Cash Flow', 'VAT Reports',
];

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) router.push('/dashboard');
  }, [isAuthenticated, router]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
      {/* Nav */}
      <nav className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur-xl dark:bg-gray-950/80">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary shadow-lg shadow-primary/30">
              <span className="text-lg font-black text-white">F</span>
            </div>
            <span className="text-xl font-bold tracking-tight">FinanceOS</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login"><Button variant="ghost" size="sm">Sign in</Button></Link>
            <Link href="/auth/register"><Button size="sm">Get Started <ArrowRight className="ml-1 h-4 w-4" /></Button></Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="mx-auto max-w-7xl px-6 py-24 text-center lg:py-40">
        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border bg-white/80 px-4 py-1.5 text-sm font-medium shadow-sm dark:bg-gray-900/80">
            <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            Enterprise-Grade Accounting System
          </div>
          <h1 className="mb-6 text-5xl font-black tracking-tight lg:text-7xl">
            Financial Management
            <br />
            <span className="bg-gradient-to-r from-blue-600 via-violet-600 to-blue-600 bg-clip-text text-transparent">
              Built for the Future
            </span>
          </h1>
          <p className="mx-auto mb-10 max-w-2xl text-lg text-muted-foreground lg:text-xl">
            Complete ERP system with real-time reporting, inventory control, payroll automation, and multi-currency support.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/auth/register">
              <Button size="lg" className="h-12 px-8 shadow-lg shadow-primary/30">
                Start Free Trial <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="h-12 px-8">
                View Demo Dashboard
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-6 pb-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <div className="rounded-2xl border bg-white p-6 shadow-sm transition-all hover:shadow-md dark:bg-gray-900">
                <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3">
                  <f.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 font-semibold">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Modules */}
      <section className="mx-auto max-w-7xl px-6 pb-20">
        <div className="rounded-3xl border bg-gradient-to-br from-primary/5 to-violet-500/5 p-12">
          <h2 className="mb-8 text-center text-3xl font-bold">Everything You Need</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            {modules.map((m) => (
              <div key={m} className="flex items-center gap-2 rounded-lg bg-white/70 px-3 py-2 text-sm font-medium dark:bg-gray-900/70">
                <CheckCircle className="h-4 w-4 flex-shrink-0 text-green-500" />
                {m}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto max-w-7xl px-6 pb-20">
        <div className="grid gap-8 text-center md:grid-cols-3">
          {[['10K+', 'Companies Using FinanceOS'], ['$2.5B+', 'Transactions Processed'], ['99.9%', 'Uptime SLA']].map(([val, label]) => (
            <div key={label}>
              <div className="mb-2 text-5xl font-black text-primary">{val}</div>
              <div className="text-muted-foreground">{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="rounded-3xl bg-gradient-to-r from-primary to-violet-600 p-16 text-center text-white">
          <h2 className="mb-4 text-4xl font-black">Ready to Transform Your Finances?</h2>
          <p className="mb-8 text-lg text-white/80">Start your free trial today. No credit card required.</p>
          <Link href="/auth/register">
            <Button size="lg" variant="secondary" className="h-12 px-10 font-semibold">
              Get Started Free <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <span className="text-sm font-black text-white">F</span>
              </div>
              <span className="font-bold">FinanceOS</span>
            </div>
            <p className="text-sm text-muted-foreground">© 2024 FinanceOS. Enterprise Accounting System.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
