'use client';
// src/app/payable/page.tsx
import { useEffect, useState } from 'react';
import { Plus, AlertCircle } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { invoicesApi } from '@/lib/api/invoices';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

export default function PayablePage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { invoicesApi.getPurchaseInvoices().then(setInvoices).catch(console.error).finally(() => setLoading(false)); }, []);

  const open = invoices.filter((i) => i.status !== 'PAID');
  const overdue = invoices.filter((i) => i.status === 'OVERDUE');
  const paid = invoices.filter((i) => i.status === 'PAID');
  const total = open.reduce((s, i) => s + (Number(i.total) - Number(i.amountPaid)), 0);
  const overdueAmt = overdue.reduce((s, i) => s + (Number(i.total) - Number(i.amountPaid)), 0);
  const paidAmt = paid.reduce((s, i) => s + Number(i.total), 0);

  const statusBadge = (s: string) => {
    const v: any = { PAID: 'success', SENT: 'warning', OVERDUE: 'destructive', DRAFT: 'secondary', PARTIAL: 'secondary' };
    return <Badge variant={v[s] || 'default'}>{s}</Badge>;
  };

  return (
    <MainLayout title="Accounts Payable" description="Supplier invoices, payments & aging analysis">
      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: 'Total Payable', val: total, sub: `${open.length} open invoices`, color: '' },
            { label: 'Due This Week', val: open.reduce((s, i) => s + (Number(i.total) - Number(i.amountPaid)), 0) / 2, sub: 'Requires attention', color: 'text-amber-500' },
            { label: 'Overdue', val: overdueAmt, sub: `${overdue.length} overdue`, color: 'text-red-500' },
            { label: 'Paid This Month', val: paidAmt, sub: 'On track', color: 'text-green-500' },
          ].map((k) => (
            <Card key={k.label}>
              <CardHeader className="pb-2"><CardDescription>{k.label}</CardDescription></CardHeader>
              <CardContent>
                {loading ? <Skeleton className="h-8 w-28" /> : <><div className={`text-2xl font-bold ${k.color}`}>{formatCurrency(k.val)}</div><p className="mt-1 text-xs text-muted-foreground">{k.sub}</p></>}
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div><CardTitle>Supplier Invoices</CardTitle><CardDescription>All purchase invoices and payables</CardDescription></div>
              <Button size="sm"><Plus className="mr-2 h-4 w-4" />Add Invoice</Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
            ) : invoices.length === 0 ? (
              <div className="py-12 text-center text-muted-foreground"><AlertCircle className="mx-auto mb-3 h-10 w-10 opacity-40" /><p>No invoices found</p></div>
            ) : (
              <div className="space-y-2">
                {invoices.map((inv) => (
                  <div key={inv.id} className="flex items-center justify-between rounded-xl border p-4 transition-colors hover:bg-muted/30">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className="font-semibold truncate">{inv.supplier?.name}</span>
                        {statusBadge(inv.status)}
                        {inv.status === 'OVERDUE' && <AlertCircle className="h-4 w-4 text-red-500 flex-shrink-0" />}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                        <span className="font-mono">{inv.invoiceNumber}</span>
                        <span>Due: {formatDate(inv.dueDate)}</span>
                        {inv.supplierRef && <span>Ref: {inv.supplierRef}</span>}
                      </div>
                    </div>
                    <div className="text-right ml-4">
                      <div className="text-lg font-bold">{formatCurrency(inv.total)}</div>
                      {Number(inv.amountPaid) > 0 && <div className="text-xs text-green-500">Paid: {formatCurrency(inv.amountPaid)}</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
