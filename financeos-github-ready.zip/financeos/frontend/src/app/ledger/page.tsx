// src/app/ledger/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ledgerApi } from '@/lib/api/ledger';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function LedgerPage() {
  const [journals, setJournals] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [journalsData, accountsData] = await Promise.all([
        ledgerApi.getJournals(),
        ledgerApi.getAccounts(),
      ]);
      setJournals(journalsData || []);
      setAccounts(accountsData || []);
    } catch (error) {
      console.error('Failed to load ledger data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      POSTED: 'success',
      DRAFT: 'secondary',
      VOID: 'destructive',
    };
    return <Badge variant={variants[status] || 'default'}>{status}</Badge>;
  };

  return (
    <MainLayout title="General Ledger" description="Chart of accounts, journal entries & trial balance">
      <div className="space-y-6">
        {/* Module Cards */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="cursor-pointer transition-all hover:shadow-lg">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-500/10">
                <span className="text-2xl">📋</span>
              </div>
              <CardTitle className="mt-4">Chart of Accounts</CardTitle>
              <CardDescription>Manage your complete account hierarchy</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-500">{accounts.length} accounts</div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer transition-all hover:shadow-lg">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-500/10">
                <span className="text-2xl">✏️</span>
              </div>
              <CardTitle className="mt-4">Journal Entries</CardTitle>
              <CardDescription>Record double-entry transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{journals.length} entries</div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer transition-all hover:shadow-lg">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-amber-500/10">
                <span className="text-2xl">⚖️</span>
              </div>
              <CardTitle className="mt-4">Trial Balance</CardTitle>
              <CardDescription>Verify debits equal credits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-500">Balanced ✓</div>
            </CardContent>
          </Card>
        </div>

        {/* Journal Entries */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Journal Entries</CardTitle>
                <CardDescription>Recent accounting entries</CardDescription>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Entry
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="posted">Posted</TabsTrigger>
                <TabsTrigger value="draft">Draft</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="mt-4">
                <div className="space-y-3">
                  {journals.slice(0, 10).map((journal) => (
                    <div key={journal.id} className="flex items-center justify-between rounded-lg border p-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-sm text-primary">{journal.refNumber}</span>
                          {getStatusBadge(journal.status)}
                        </div>
                        <p className="mt-1 font-medium">{journal.description}</p>
                        <p className="mt-1 text-sm text-muted-foreground">{formatDate(journal.date)}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Debit</div>
                        <div className="font-semibold">{formatCurrency(journal.totalDebit)}</div>
                      </div>
                      <div className="ml-8 text-right">
                        <div className="text-sm text-muted-foreground">Credit</div>
                        <div className="font-semibold">{formatCurrency(journal.totalCredit)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

// src/app/payable/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { invoicesApi } from '@/lib/api/invoices';
import { formatCurrency, formatDate } from '@/lib/utils';

export default function PayablePage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await invoicesApi.getPurchaseInvoices();
      setInvoices(data || []);
    } catch (error) {
      console.error('Failed to load invoices:', error);
    } finally {
      setLoading(false);
    }
  };

  const stats = {
    total: invoices.reduce((sum, inv) => sum + Number(inv.total - inv.amountPaid), 0),
    dueThisWeek: invoices.filter((inv) => inv.status === 'SENT').reduce((sum, inv) => sum + Number(inv.total - inv.amountPaid), 0),
    overdue: invoices.filter((inv) => inv.status === 'OVERDUE').reduce((sum, inv) => sum + Number(inv.total - inv.amountPaid), 0),
    paid: invoices.filter((inv) => inv.status === 'PAID').reduce((sum, inv) => sum + Number(inv.total), 0),
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      PAID: 'success',
      SENT: 'warning',
      OVERDUE: 'destructive',
      PARTIAL: 'secondary',
    };
    return <Badge variant={variants[status] || 'default'}>{status}</Badge>;
  };

  return (
    <MainLayout title="Accounts Payable" description="Supplier invoices, payments & aging analysis">
      <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Total Payable</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats.total)}</div>
              <p className="mt-1 text-xs text-muted-foreground">{invoices.filter(i => i.status !== 'PAID').length} invoices open</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Due This Week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-500">{formatCurrency(stats.dueThisWeek)}</div>
              <p className="mt-1 text-xs text-muted-foreground">Requires attention</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Overdue</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">{formatCurrency(stats.overdue)}</div>
              <p className="mt-1 text-xs text-muted-foreground">{invoices.filter(i => i.status === 'OVERDUE').length} invoices overdue</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Paid This Month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{formatCurrency(stats.paid)}</div>
              <p className="mt-1 text-xs text-muted-foreground">On track</p>
            </CardContent>
          </Card>
        </div>

        {/* Invoices Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Supplier Invoices</CardTitle>
                <CardDescription>Manage payables and payments</CardDescription>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Invoice
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {invoices.map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="font-medium">{invoice.supplier.name}</span>
                      {getStatusBadge(invoice.status)}
                    </div>
                    <div className="mt-1 flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="font-mono">{invoice.invoiceNumber}</span>
                      <span>Due: {formatDate(invoice.dueDate)}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold">{formatCurrency(invoice.total)}</div>
                    {invoice.amountPaid > 0 && (
                      <div className="text-sm text-muted-foreground">
                        Paid: {formatCurrency(invoice.amountPaid)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

// src/app/receivable/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { invoicesApi } from '@/lib/api/invoices';
import { formatCurrency, formatDate } from '@/lib/utils';

export default function ReceivablePage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await invoicesApi.getSalesInvoices();
      setInvoices(data || []);
    } catch (error) {
      console.error('Failed to load invoices:', error);
    } finally {
      setLoading(false);
    }
  };

  const stats = {
    total: invoices.reduce((sum, inv) => sum + Number(inv.total - inv.amountPaid), 0),
    collected: invoices.filter((inv) => inv.status === 'PAID').reduce((sum, inv) => sum + Number(inv.total), 0),
    overdue: invoices.filter((inv) => inv.status === 'OVERDUE').reduce((sum, inv) => sum + Number(inv.total - inv.amountPaid), 0),
    collectionRate: 94.2,
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      PAID: 'success',
      SENT: 'warning',
      OVERDUE: 'destructive',
      PARTIAL: 'secondary',
    };
    return <Badge variant={variants[status] || 'default'}>{status}</Badge>;
  };

  return (
    <MainLayout title="Accounts Receivable" description="Customer invoices, collections & aging">
      <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Total Receivable</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats.total)}</div>
              <p className="mt-1 text-xs text-muted-foreground">{invoices.filter(i => i.status !== 'PAID').length} open invoices</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Collected MTD</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{formatCurrency(stats.collected)}</div>
              <p className="mt-1 text-xs text-green-500">+31% vs last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Overdue</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">{formatCurrency(stats.overdue)}</div>
              <p className="mt-1 text-xs text-muted-foreground">{invoices.filter(i => i.status === 'OVERDUE').length} customers</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Collection Rate</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{stats.collectionRate}%</div>
              <p className="mt-1 text-xs text-green-500">Excellent</p>
            </CardContent>
          </Card>
        </div>

        {/* Invoices Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Customer Invoices</CardTitle>
                <CardDescription>Track receivables and payments</CardDescription>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Invoice
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {invoices.map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="font-medium">{invoice.customer.name}</span>
                      {getStatusBadge(invoice.status)}
                    </div>
                    <div className="mt-1 flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="font-mono text-primary">{invoice.invoiceNumber}</span>
                      <span>Issued: {formatDate(invoice.date)}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-green-500">{formatCurrency(invoice.total)}</div>
                    {invoice.amountPaid > 0 && (
                      <div className="text-sm text-muted-foreground">
                        Collected: {formatCurrency(invoice.amountPaid)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
