// src/app/inventory/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { Plus, Package, Warehouse, TrendingDown } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { inventoryApi } from '@/lib/api/inventory';
import { formatCurrency } from '@/lib/utils';

export default function InventoryPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [stockLevels, setStockLevels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [productsData, stockData] = await Promise.all([
        inventoryApi.getProducts(),
        inventoryApi.getStockLevels(),
      ]);
      setProducts(productsData || []);
      setStockLevels(stockData || []);
    } catch (error) {
      console.error('Failed to load inventory:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalValue = stockLevels.reduce((sum, item) => {
    const stockValue = item.stockByWarehouse?.reduce((s: number, w: any) => s + w.value, 0) || 0;
    return sum + stockValue;
  }, 0);

  const lowStockItems = stockLevels.filter((item) => item.totalQuantity < item.reorderPoint);

  return (
    <MainLayout title="Inventory Management" description="Products, warehouses, stock movements & valuation">
      <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total SKUs</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.length}</div>
              <p className="text-xs text-muted-foreground">Across 3 warehouses</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
              <Warehouse className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{formatCurrency(totalValue)}</div>
              <p className="text-xs text-green-500">+5.8% this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Low Stock Alerts</CardTitle>
              <TrendingDown className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500">{lowStockItems.length}</div>
              <p className="text-xs text-muted-foreground">Needs reorder</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Turnover Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-500">4.8x</div>
              <p className="text-xs text-muted-foreground">Annual average</p>
            </CardContent>
          </Card>
        </div>

        {/* Product Stock Levels */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Product Stock Levels</CardTitle>
                <CardDescription>Current inventory status</CardDescription>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Product
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stockLevels.map((item) => {
                const isLowStock = item.totalQuantity < item.reorderPoint;
                return (
                  <div key={item.id} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <span className="font-medium">{item.name}</span>
                        {isLowStock && <Badge variant="destructive">Low Stock</Badge>}
                        {item.category && <Badge variant="outline">{item.category}</Badge>}
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">SKU: {item.sku}</p>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Stock</div>
                        <div className={`text-lg font-semibold ${isLowStock ? 'text-red-500' : ''}`}>
                          {item.totalQuantity} units
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Reorder Point</div>
                        <div className="text-lg font-semibold">{item.reorderPoint}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Value</div>
                        <div className="text-lg font-semibold">
                          {formatCurrency(item.stockByWarehouse?.[0]?.value || 0)}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

// src/app/reports/page.tsx
'use client';

import { useState } from 'react';
import { FileText, Download, TrendingUp, DollarSign } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { formatCurrency } from '@/lib/utils';

export default function ReportsPage() {
  const [selectedReport, setSelectedReport] = useState<string | null>(null);

  const reports = [
    {
      id: 'income-statement',
      title: 'Income Statement',
      description: 'Profit & Loss report',
      icon: TrendingUp,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      id: 'balance-sheet',
      title: 'Balance Sheet',
      description: 'Assets, liabilities & equity',
      icon: DollarSign,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
    },
    {
      id: 'cash-flow',
      title: 'Cash Flow Statement',
      description: 'Operating, investing & financing',
      icon: FileText,
      color: 'text-amber-500',
      bgColor: 'bg-amber-500/10',
    },
    {
      id: 'trial-balance',
      title: 'Trial Balance',
      description: 'Verify accounting accuracy',
      icon: FileText,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
    },
  ];

  const incomeStatementData = {
    revenues: [
      { name: 'Product Sales', amount: 1842400 },
      { name: 'Service Revenue', amount: 684200 },
      { name: 'Subscription Income', amount: 312000 },
    ],
    expenses: [
      { name: 'Cost of Goods Sold', amount: 842000 },
      { name: 'Payroll & Benefits', amount: 724800 },
      { name: 'Marketing & Advertising', amount: 184200 },
      { name: 'Operations & Overhead', amount: 158600 },
    ],
  };

  const totalRevenue = incomeStatementData.revenues.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = incomeStatementData.expenses.reduce((sum, item) => sum + item.amount, 0);
  const netProfit = totalRevenue - totalExpenses;

  return (
    <MainLayout title="Financial Reports" description="Income statement, balance sheet, cash flow & more">
      <div className="space-y-6">
        {/* Report Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          {reports.map((report) => {
            const Icon = report.icon;
            return (
              <Card
                key={report.id}
                className="cursor-pointer transition-all hover:shadow-lg"
                onClick={() => setSelectedReport(report.id)}
              >
                <CardHeader>
                  <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${report.bgColor}`}>
                    <Icon className={`h-6 w-6 ${report.color}`} />
                  </div>
                  <CardTitle className="mt-4 text-base">{report.title}</CardTitle>
                  <CardDescription className="text-xs">{report.description}</CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>

        {/* Report Display */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Income Statement</CardTitle>
                <CardDescription>Q4 2024 · January 1 - December 31, 2024</CardDescription>
              </div>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export PDF
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Revenue Section */}
              <div>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Revenue</h3>
                <div className="space-y-2">
                  {incomeStatementData.revenues.map((item) => (
                    <div key={item.name} className="flex justify-between border-b py-2">
                      <span>{item.name}</span>
                      <span className="font-semibold text-green-500">{formatCurrency(item.amount)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t-2 py-3 font-bold">
                    <span>Total Revenue</span>
                    <span className="text-green-500">{formatCurrency(totalRevenue)}</span>
                  </div>
                </div>
              </div>

              {/* Expenses Section */}
              <div>
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Expenses</h3>
                <div className="space-y-2">
                  {incomeStatementData.expenses.map((item) => (
                    <div key={item.name} className="flex justify-between border-b py-2">
                      <span>{item.name}</span>
                      <span className="font-semibold text-red-500">-{formatCurrency(item.amount)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t-2 py-3 font-bold">
                    <span>Total Expenses</span>
                    <span className="text-red-500">-{formatCurrency(totalExpenses)}</span>
                  </div>
                </div>
              </div>

              {/* Net Profit */}
              <div className="rounded-lg bg-green-50 p-4 dark:bg-green-950">
                <div className="flex justify-between text-lg font-bold">
                  <span>Net Profit</span>
                  <span className="text-green-600 dark:text-green-400">{formatCurrency(netProfit)}</span>
                </div>
                <p className="mt-2 text-sm text-green-600 dark:text-green-400">
                  Profit Margin: {((netProfit / totalRevenue) * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

// src/app/payroll/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { Plus, Users } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { payrollApi } from '@/lib/api/payroll';
import { formatCurrency } from '@/lib/utils';

export default function PayrollPage() {
  const [employees, setEmployees] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [employeesData, departmentsData] = await Promise.all([
        payrollApi.getEmployees(),
        payrollApi.getDepartments(),
      ]);
      setEmployees(employeesData || []);
      setDepartments(departmentsData || []);
    } catch (error) {
      console.error('Failed to load payroll data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalPayroll = employees.reduce((sum, emp) => sum + Number(emp.salary), 0);
  const avgSalary = employees.length > 0 ? totalPayroll / employees.length : 0;

  return (
    <MainLayout title="HR & Payroll" description="Employees, salaries, attendance & deductions">
      <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{employees.length}</div>
              <p className="text-xs text-green-500">+4 this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Payroll MTD</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(totalPayroll)}</div>
              <p className="text-xs text-muted-foreground">{departments.length} departments</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Leaves</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">14</div>
              <p className="text-xs text-muted-foreground">Needs approval</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Salary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(avgSalary)}</div>
              <p className="text-xs text-green-500">+8.2% YoY</p>
            </CardContent>
          </Card>
        </div>

        {/* Departments Overview */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Department Overview</CardTitle>
                <CardDescription>Headcount and payroll by department</CardDescription>
              </div>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Employee
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {departments.map((dept) => {
                const deptEmployees = employees.filter((e) => e.departmentId === dept.id);
                const deptPayroll = deptEmployees.reduce((sum, e) => sum + Number(e.salary), 0);
                const deptAvg = deptEmployees.length > 0 ? deptPayroll / deptEmployees.length : 0;

                return (
                  <div key={dept.id} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex-1">
                      <div className="font-medium">{dept.name}</div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {deptEmployees.length} employees
                      </p>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Monthly Payroll</div>
                        <div className="text-lg font-semibold text-red-500">
                          {formatCurrency(deptPayroll)}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Avg Salary</div>
                        <div className="text-lg font-semibold">{formatCurrency(deptAvg)}</div>
                      </div>
                      <div className="text-right">
                        <Badge variant="success">98.2%</Badge>
                        <div className="mt-1 text-xs text-muted-foreground">Attendance</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

// src/app/settings/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { settingsApi } from '@/lib/api/settings';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function SettingsPage() {
  const { toast } = useToast();
  const [company, setCompany] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const companyData = await settingsApi.getCompany();
      setCompany(companyData);
    } catch (error) {
      console.error('Failed to load settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      await settingsApi.updateCompany(company);
      toast({ title: 'Settings saved', description: 'Company information updated successfully' });
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to save settings' });
    }
  };

  const roles = [
    { name: 'Super Admin', count: 2, access: 'Full Access' },
    { name: 'CFO / Finance Manager', count: 3, access: 'Finance + Reports' },
    { name: 'Accountant', count: 8, access: 'Entries + View' },
    { name: 'HR Manager', count: 4, access: 'HR Only' },
    { name: 'Viewer', count: 12, access: 'Read Only' },
  ];

  return (
    <MainLayout title="Settings" description="Company profile, fiscal year, currency & permissions">
      <Tabs defaultValue="company" className="space-y-6">
        <TabsList>
          <TabsTrigger value="company">Company</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>Update your company details and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Company Name</Label>
                  <Input
                    id="name"
                    value={company?.name || ''}
                    onChange={(e) => setCompany({ ...company, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxId">Tax ID / VAT Number</Label>
                  <Input
                    id="taxId"
                    value={company?.vatNumber || ''}
                    onChange={(e) => setCompany({ ...company, vatNumber: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  value={company?.address || ''}
                  onChange={(e) => setCompany({ ...company, address: e.target.value })}
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={company?.city || ''}
                    onChange={(e) => setCompany({ ...company, city: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Input
                    id="country"
                    value={company?.country || ''}
                    onChange={(e) => setCompany({ ...company, country: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="currency">Base Currency</Label>
                  <Input id="currency" value={company?.currency || 'USD'} disabled />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Input id="timezone" value={company?.timezone || ''} disabled />
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSave}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Roles & Permissions</CardTitle>
              <CardDescription>Manage access levels for your team</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {roles.map((role) => (
                  <div key={role.name} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex-1">
                      <div className="font-medium">{role.name}</div>
                      <p className="mt-1 text-sm text-muted-foreground">{role.count} users</p>
                    </div>
                    <Badge variant={role.access === 'Full Access' ? 'default' : 'secondary'}>
                      {role.access}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Billing & Subscription</CardTitle>
              <CardDescription>Manage your plan and payment method</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-lg border p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">Enterprise Plan</div>
                      <p className="mt-1 text-sm text-muted-foreground">Unlimited users and features</p>
                    </div>
                    <Badge>Active</Badge>
                  </div>
                  <div className="mt-4 flex items-baseline gap-2">
                    <span className="text-3xl font-bold">$299</span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  Manage Subscription
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}
