'use client';

import { useState, useCallback } from 'react';
import { FileText, Download, TrendingUp, DollarSign, BarChart3, Receipt } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { formatCurrency, formatPercent } from '@/lib/utils';
import { reportsApi } from '@/lib/api/reports';
import { Skeleton } from '@/components/ui/skeleton';

const STATIC_P_AND_L = {
  revenues: [
    { code: '4100', name: 'Product Sales Revenue', net: 1842400 },
    { code: '4200', name: 'Service Revenue', net: 684200 },
    { code: '4300', name: 'Subscription Income', net: 312000 },
  ],
  expenses: [
    { code: '5100', name: 'Cost of Goods Sold', net: 842000 },
    { code: '5200', name: 'Payroll & Benefits', net: 724800 },
    { code: '5400', name: 'Marketing & Advertising', net: 184200 },
    { code: '5300', name: 'Operations & Overhead', net: 158600 },
  ],
};

const STATIC_BALANCE_SHEET = {
  assets: [
    { code: '1102', name: 'Bank — CIB Main Account', balance: 1240000 },
    { code: '1200', name: 'Accounts Receivable', balance: 418400 },
    { code: '1300', name: 'Inventory', balance: 284000 },
    { code: '1510', name: 'Office Equipment', balance: 128000 },
    { code: '1520', name: 'Computers & Servers', balance: 96000 },
  ],
  liabilities: [
    { code: '2101', name: 'Accounts Payable', balance: 284000 },
    { code: '2200', name: 'VAT Payable', balance: 48400 },
    { code: '2300', name: 'Salaries Payable', balance: 218400 },
    { code: '2410', name: 'Bank Loans', balance: 400000 },
  ],
  equity: [
    { code: '3100', name: 'Share Capital', balance: 500000 },
    { code: '3200', name: 'Retained Earnings', balance: 586600 },
    { code: '3300', name: 'Current Year Profit', balance: 129000 },
  ],
};

export default function ReportsPage() {
  const [tab, setTab] = useState('income');

  const totalRevenue = STATIC_P_AND_L.revenues.reduce((s, r) => s + r.net, 0);
  const totalExpenses = STATIC_P_AND_L.expenses.reduce((s, e) => s + e.net, 0);
  const netProfit = totalRevenue - totalExpenses;

  const totalAssets = STATIC_BALANCE_SHEET.assets.reduce((s, a) => s + a.balance, 0);
  const totalLiabilities = STATIC_BALANCE_SHEET.liabilities.reduce((s, l) => s + l.balance, 0);
  const totalEquity = STATIC_BALANCE_SHEET.equity.reduce((s, e) => s + e.balance, 0);

  const vatOutput = 84200 * 0.14 + 56800 * 0.14 + 124500 * 0.14;
  const vatInput = 48200 * 0.14 + 12450 * 0.14 + 38000 * 0.14;
  const vatDue = vatOutput - vatInput;

  const reportCards = [
    { id: 'income', label: 'Income Statement', icon: TrendingUp, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { id: 'balance', label: 'Balance Sheet', icon: DollarSign, color: 'text-green-500', bg: 'bg-green-500/10' },
    { id: 'cashflow', label: 'Cash Flow', icon: BarChart3, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { id: 'vat', label: 'VAT Report', icon: Receipt, color: 'text-purple-500', bg: 'bg-purple-500/10' },
  ];

  const handleExportPDF = useCallback(() => {
    const content = `
FinanceOS - Financial Report
Q4 2024

INCOME STATEMENT
================
Total Revenue: ${formatCurrency(totalRevenue)}
Total Expenses: -${formatCurrency(totalExpenses)}
Net Profit: ${formatCurrency(netProfit)}
Profit Margin: ${formatPercent((netProfit / totalRevenue) * 100)}
    `;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'financeos-report-q4-2024.txt';
    a.click();
  }, [totalRevenue, totalExpenses, netProfit]);

  return (
    <MainLayout title="Financial Reports" description="P&L, balance sheet, cash flow, VAT & more">
      <div className="space-y-6">
        {/* Report type cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {reportCards.map((r) => (
            <Card key={r.id} className={`cursor-pointer transition-all hover:shadow-md ${tab === r.id ? 'ring-2 ring-primary' : ''}`} onClick={() => setTab(r.id)}>
              <CardHeader className="pb-3">
                <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${r.bg}`}>
                  <r.icon className={`h-5 w-5 ${r.color}`} />
                </div>
                <CardTitle className="mt-3 text-sm font-semibold">{r.label}</CardTitle>
              </CardHeader>
            </Card>
          ))}
        </div>

        {/* Report content */}
        {tab === 'income' && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div><CardTitle>Income Statement</CardTitle><CardDescription>Fiscal Year 2024 · Jan 1 – Dec 31</CardDescription></div>
                <Button variant="outline" size="sm" onClick={handleExportPDF}><Download className="mr-2 h-4 w-4" />Export</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Revenue</h3>
                  <div className="space-y-1">
                    {STATIC_P_AND_L.revenues.map((r) => (
                      <div key={r.code} className="flex justify-between border-b py-2.5 text-sm">
                        <span className="flex items-center gap-3"><span className="font-mono text-xs text-muted-foreground">{r.code}</span>{r.name}</span>
                        <span className="font-semibold text-green-600">{formatCurrency(r.net)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between border-t-2 py-3 font-bold"><span>Total Revenue</span><span className="text-green-600">{formatCurrency(totalRevenue)}</span></div>
                  </div>
                </div>
                <div>
                  <h3 className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Expenses</h3>
                  <div className="space-y-1">
                    {STATIC_P_AND_L.expenses.map((e) => (
                      <div key={e.code} className="flex justify-between border-b py-2.5 text-sm">
                        <span className="flex items-center gap-3"><span className="font-mono text-xs text-muted-foreground">{e.code}</span>{e.name}</span>
                        <span className="font-semibold text-red-600">({formatCurrency(e.net)})</span>
                      </div>
                    ))}
                    <div className="flex justify-between border-t-2 py-3 font-bold"><span>Total Expenses</span><span className="text-red-600">({formatCurrency(totalExpenses)})</span></div>
                  </div>
                </div>
                <div className="rounded-xl bg-gradient-to-r from-green-50 to-emerald-50 p-6 dark:from-green-950 dark:to-emerald-950">
                  <div className="flex justify-between text-xl font-black"><span>Net Profit</span><span className="text-green-600">{formatCurrency(netProfit)}</span></div>
                  <div className="mt-2 flex gap-6 text-sm text-muted-foreground">
                    <span>Profit Margin: <strong className="text-green-600">{formatPercent((netProfit / totalRevenue) * 100)}</strong></span>
                    <span>Revenue Growth: <strong className="text-blue-600">+18.2%</strong></span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {tab === 'balance' && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div><CardTitle>Balance Sheet</CardTitle><CardDescription>As of December 31, 2024</CardDescription></div>
                <Button variant="outline" size="sm" onClick={handleExportPDF}><Download className="mr-2 h-4 w-4" />Export</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h3 className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Assets</h3>
                  {STATIC_BALANCE_SHEET.assets.map((a) => (
                    <div key={a.code} className="flex justify-between border-b py-2.5 text-sm">
                      <span className="flex items-center gap-2"><span className="font-mono text-xs text-muted-foreground">{a.code}</span>{a.name}</span>
                      <span className="font-semibold">{formatCurrency(a.balance)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t-2 py-3 font-bold text-blue-600"><span>Total Assets</span><span>{formatCurrency(totalAssets)}</span></div>
                </div>
                <div>
                  <h3 className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Liabilities</h3>
                  {STATIC_BALANCE_SHEET.liabilities.map((l) => (
                    <div key={l.code} className="flex justify-between border-b py-2.5 text-sm">
                      <span className="flex items-center gap-2"><span className="font-mono text-xs text-muted-foreground">{l.code}</span>{l.name}</span>
                      <span className="font-semibold">{formatCurrency(l.balance)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t-2 py-3 font-bold text-red-600"><span>Total Liabilities</span><span>{formatCurrency(totalLiabilities)}</span></div>
                  <h3 className="mb-3 mt-6 text-xs font-semibold uppercase tracking-widest text-muted-foreground">Equity</h3>
                  {STATIC_BALANCE_SHEET.equity.map((e) => (
                    <div key={e.code} className="flex justify-between border-b py-2.5 text-sm">
                      <span className="flex items-center gap-2"><span className="font-mono text-xs text-muted-foreground">{e.code}</span>{e.name}</span>
                      <span className="font-semibold">{formatCurrency(e.balance)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between border-t-2 py-3 font-bold text-green-600"><span>Total Equity</span><span>{formatCurrency(totalEquity)}</span></div>
                  <div className={`mt-3 rounded-lg p-3 text-center text-sm font-semibold ${totalAssets === totalLiabilities + totalEquity ? 'bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300' : 'bg-red-50 text-red-700 dark:bg-red-950'}`}>
                    {totalAssets === totalLiabilities + totalEquity ? '✓ Balance Sheet is Balanced' : '✗ Balance Sheet Imbalanced'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {tab === 'cashflow' && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div><CardTitle>Cash Flow Statement</CardTitle><CardDescription>Q4 2024 · Oct 1 – Dec 31</CardDescription></div>
                <Button variant="outline" size="sm" onClick={handleExportPDF}><Download className="mr-2 h-4 w-4" />Export</Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {[
                { title: 'Operating Activities', items: [['Cash received from customers', 842000], ['Cash paid to suppliers', -284000], ['Cash paid for payroll', -218400], ['Tax payments', -48000]], color: 'blue' },
                { title: 'Investing Activities', items: [['Purchase of equipment', -64000], ['Software licenses', -28000]], color: 'amber' },
                { title: 'Financing Activities', items: [['Loan repayments', -50000], ['Dividends paid', -100000]], color: 'purple' },
              ].map((section) => {
                const sectionTotal = section.items.reduce((s, [, v]) => s + (v as number), 0);
                return (
                  <div key={section.title}>
                    <h3 className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">{section.title}</h3>
                    {section.items.map(([name, val]) => (
                      <div key={name as string} className="flex justify-between border-b py-2.5 text-sm">
                        <span>{name as string}</span>
                        <span className={`font-semibold ${(val as number) >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(val as number)}</span>
                      </div>
                    ))}
                    <div className="flex justify-between border-t-2 py-2.5 font-bold">
                      <span>Net {section.title}</span>
                      <span className={sectionTotal >= 0 ? 'text-green-600' : 'text-red-600'}>{formatCurrency(sectionTotal)}</span>
                    </div>
                  </div>
                );
              })}
              <div className="rounded-xl bg-blue-50 p-4 dark:bg-blue-950">
                <div className="flex justify-between font-black text-lg"><span>Net Cash Position</span><span className="text-blue-600">{formatCurrency(842000 - 284000 - 218400 - 48000 - 64000 - 28000 - 50000 - 100000)}</span></div>
              </div>
            </CardContent>
          </Card>
        )}

        {tab === 'vat' && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div><CardTitle>VAT Report</CardTitle><CardDescription>Q4 2024 · Oct 1 – Dec 31</CardDescription></div>
                <Button variant="outline" size="sm" onClick={handleExportPDF}><Download className="mr-2 h-4 w-4" />Export</Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border p-4">
                  <h3 className="mb-3 font-semibold text-green-600">Output VAT (Sales)</h3>
                  <div className="flex justify-between py-2 text-sm"><span>Taxable Sales</span><span>{formatCurrency(totalRevenue)}</span></div>
                  <div className="flex justify-between py-2 text-sm border-t"><span>VAT @ 14%</span><span className="font-bold text-green-600">{formatCurrency(vatOutput)}</span></div>
                </div>
                <div className="rounded-xl border p-4">
                  <h3 className="mb-3 font-semibold text-red-600">Input VAT (Purchases)</h3>
                  <div className="flex justify-between py-2 text-sm"><span>Taxable Purchases</span><span>{formatCurrency(totalExpenses * 0.7)}</span></div>
                  <div className="flex justify-between py-2 text-sm border-t"><span>VAT @ 14%</span><span className="font-bold text-red-600">{formatCurrency(vatInput)}</span></div>
                </div>
              </div>
              <div className={`rounded-xl p-6 text-center ${vatDue >= 0 ? 'bg-amber-50 dark:bg-amber-950' : 'bg-green-50 dark:bg-green-950'}`}>
                <p className="text-sm text-muted-foreground mb-1">{vatDue >= 0 ? 'VAT Payable to Tax Authority' : 'VAT Refund Due'}</p>
                <p className={`text-3xl font-black ${vatDue >= 0 ? 'text-amber-600' : 'text-green-600'}`}>{formatCurrency(Math.abs(vatDue))}</p>
                <p className="mt-2 text-xs text-muted-foreground">Due by January 31, 2025</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
