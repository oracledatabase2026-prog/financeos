// src/app/dashboard/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, DollarSign, Wallet, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { dashboardApi } from '@/lib/api/dashboard';
import { formatCurrency, formatPercent } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { RevenueChart } from '@/components/charts/revenue-chart';
import { ExpenseChart } from '@/components/charts/expense-chart';
import { TransactionsTable } from '@/components/tables/transactions-table';
import { TopCustomersChart } from '@/components/charts/top-customers-chart';

export default function DashboardPage() {
  const [kpis, setKPIs] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await dashboardApi.getKPIs();
      setKPIs(data);
    } catch (error) {
      console.error('Failed to load KPIs:', error);
    } finally {
      setLoading(false);
    }
  };

  const kpiCards = [
    {
      title: 'Total Revenue',
      value: kpis?.revenue?.value || 0,
      change: kpis?.revenue?.change || 0,
      trend: kpis?.revenue?.trend,
      icon: DollarSign,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: 'Net Profit',
      value: kpis?.profit?.value || 0,
      change: kpis?.profit?.change || 0,
      trend: kpis?.profit?.trend,
      icon: TrendingUp,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
    },
    {
      title: 'Total Expenses',
      value: kpis?.expenses?.value || 0,
      change: kpis?.expenses?.change || 0,
      trend: kpis?.expenses?.trend,
      icon: TrendingDown,
      color: 'text-amber-500',
      bgColor: 'bg-amber-500/10',
    },
    {
      title: 'Cash Flow',
      value: kpis?.cashFlow?.value || 0,
      change: kpis?.cashFlow?.change || 0,
      trend: kpis?.cashFlow?.trend,
      icon: Wallet,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
    },
  ];

  return (
    <MainLayout title="Dashboard" description="Financial overview and key metrics">
      <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {kpiCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="overflow-hidden">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">{card.title}</CardTitle>
                    <div className={`rounded-lg p-2 ${card.bgColor}`}>
                      <Icon className={`h-4 w-4 ${card.color}`} />
                    </div>
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <Skeleton className="h-8 w-32" />
                    ) : (
                      <>
                        <div className="text-2xl font-bold">{formatCurrency(card.value)}</div>
                        <div className="mt-1 flex items-center text-xs">
                          {card.trend === 'up' ? (
                            <ArrowUpRight className="mr-1 h-3 w-3 text-green-500" />
                          ) : (
                            <ArrowDownRight className="mr-1 h-3 w-3 text-red-500" />
                          )}
                          <span className={card.trend === 'up' ? 'text-green-500' : 'text-red-500'}>
                            {formatPercent(card.change)}
                          </span>
                          <span className="ml-1 text-muted-foreground">vs last quarter</span>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Charts Row */}
        <div className="grid gap-4 md:grid-cols-7">
          <Card className="col-span-4">
            <CardHeader>
              <CardTitle>Revenue vs Expenses</CardTitle>
              <CardDescription>Monthly comparison for 2024</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <RevenueChart />
            </CardContent>
          </Card>
          <Card className="col-span-3">
            <CardHeader>
              <CardTitle>Expense Breakdown</CardTitle>
              <CardDescription>By category</CardDescription>
            </CardHeader>
            <CardContent>
              <ExpenseChart />
            </CardContent>
          </Card>
        </div>

        {/* Tables Row */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Last 5 entries</CardDescription>
            </CardHeader>
            <CardContent>
              <TransactionsTable />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Top Clients</CardTitle>
              <CardDescription>By revenue · Q4 2024</CardDescription>
            </CardHeader>
            <CardContent>
              <TopCustomersChart />
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
