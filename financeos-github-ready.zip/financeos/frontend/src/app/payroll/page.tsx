'use client';

import { useEffect, useState } from 'react';
import { Plus, Users, Building2, CalendarCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { payrollApi } from '@/lib/api/payroll';
import { formatCurrency } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';

export default function PayrollPage() {
  const { toast } = useToast();
  const [employees, setEmployees] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    Promise.all([payrollApi.getEmployees(), payrollApi.getDepartments(), payrollApi.getPayrollEntries()])
      .then(([e, d, p]) => { setEmployees(e || []); setDepartments(d || []); setEntries(p || []); })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const totalPayroll = employees.reduce((s, e) => s + Number(e.salary), 0);
  const avgSalary = employees.length ? totalPayroll / employees.length : 0;

  const handleGeneratePayroll = async () => {
    setGenerating(true);
    try {
      await payrollApi.generatePayroll({ period: new Date().toISOString().slice(0, 7) });
      toast({ title: 'Payroll generated', description: `Processed for ${employees.length} employees` });
      const p = await payrollApi.getPayrollEntries();
      setEntries(p || []);
    } catch {
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to generate payroll' });
    } finally {
      setGenerating(false);
    }
  };

  const kpis = [
    { label: 'Total Employees', value: employees.length, sub: '+4 this month', color: '', icon: Users },
    { label: 'Payroll MTD', value: formatCurrency(totalPayroll), sub: `${departments.length} departments`, color: '', icon: Building2 },
    { label: 'Pending Leaves', value: '14', sub: 'Needs approval', color: 'text-amber-500', icon: CalendarCheck },
    { label: 'Avg Salary', value: formatCurrency(avgSalary), sub: '+8.2% YoY', color: 'text-green-500', icon: Users },
  ];

  return (
    <MainLayout title="HR & Payroll" description="Employees, salaries, attendance & deductions">
      <div className="space-y-6">
        {/* KPIs */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((k, i) => (
            <motion.div key={k.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardDescription>{k.label}</CardDescription>
                  <k.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  {loading ? <Skeleton className="h-8 w-24" /> : (
                    <><div className={`text-2xl font-bold ${k.color}`}>{k.value}</div><p className="mt-1 text-xs text-muted-foreground">{k.sub}</p></>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <Tabs defaultValue="departments">
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="departments">Departments</TabsTrigger>
              <TabsTrigger value="employees">Employees</TabsTrigger>
              <TabsTrigger value="payroll">Payroll Entries</TabsTrigger>
            </TabsList>
            <Button size="sm" onClick={handleGeneratePayroll} disabled={generating}>
              <Plus className="mr-2 h-4 w-4" />{generating ? 'Generating...' : 'Generate Payroll'}
            </Button>
          </div>

          <TabsContent value="departments" className="mt-4">
            <Card>
              <CardHeader><CardTitle>Department Overview</CardTitle><CardDescription>Headcount and payroll by department</CardDescription></CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
                ) : (
                  <div className="space-y-2">
                    {departments.map((dept) => {
                      const deptEmps = employees.filter((e) => e.departmentId === dept.id);
                      const deptPayroll = deptEmps.reduce((s, e) => s + Number(e.salary), 0);
                      const avg = deptEmps.length ? deptPayroll / deptEmps.length : 0;
                      return (
                        <div key={dept.id} className="flex items-center justify-between rounded-xl border p-4">
                          <div className="flex-1">
                            <div className="font-semibold">{dept.name}</div>
                            <p className="text-sm text-muted-foreground">{deptEmps.length} employees</p>
                          </div>
                          <div className="flex items-center gap-8">
                            <div className="text-right"><div className="text-xs text-muted-foreground">Monthly Payroll</div><div className="font-bold text-red-600">{formatCurrency(deptPayroll)}</div></div>
                            <div className="text-right"><div className="text-xs text-muted-foreground">Avg Salary</div><div className="font-bold">{formatCurrency(avg)}</div></div>
                            <Badge variant="success">98.2%</Badge>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="employees" className="mt-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div><CardTitle>Employee Directory</CardTitle><CardDescription>All active employees</CardDescription></div>
                  <Button size="sm"><Plus className="mr-2 h-4 w-4" />Add Employee</Button>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
                ) : (
                  <div className="space-y-2">
                    {employees.map((emp) => (
                      <div key={emp.id} className="flex items-center justify-between rounded-xl border p-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                            {emp.firstName[0]}{emp.lastName[0]}
                          </div>
                          <div>
                            <div className="font-semibold">{emp.firstName} {emp.lastName}</div>
                            <div className="text-sm text-muted-foreground">{emp.position || 'Staff'} · {emp.department?.name || 'N/A'}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <div className="text-xs text-muted-foreground">Monthly Salary</div>
                            <div className="font-bold">{formatCurrency(emp.salary)}</div>
                          </div>
                          <Badge variant={emp.status === 'ACTIVE' ? 'success' : 'secondary'}>{emp.status}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payroll" className="mt-4">
            <Card>
              <CardHeader><CardTitle>Payroll Entries</CardTitle><CardDescription>Salary processing history</CardDescription></CardHeader>
              <CardContent>
                {entries.length === 0 ? (
                  <div className="py-12 text-center">
                    <p className="text-muted-foreground">No payroll entries. Click "Generate Payroll" to process.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {entries.map((entry) => (
                      <div key={entry.id} className="flex items-center justify-between rounded-xl border p-4">
                        <div>
                          <div className="font-semibold">{entry.employee?.firstName} {entry.employee?.lastName}</div>
                          <div className="text-sm text-muted-foreground">Period: {entry.period}</div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right"><div className="text-xs text-muted-foreground">Net Salary</div><div className="font-bold text-green-600">{formatCurrency(entry.netSalary)}</div></div>
                          <Badge variant={entry.status === 'PAID' ? 'success' : 'warning'}>{entry.status}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      <Toaster />
    </MainLayout>
  );
}
